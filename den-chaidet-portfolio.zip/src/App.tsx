import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Education from './components/Education';
import Projects from './components/Projects';
import Experience from './components/Experience';
import Certificates from './components/Certificates';
import Interests from './components/Interests';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';

export default function App() {
  return (
    <div className="bg-[#020617] text-white min-h-screen font-sans selection:bg-sky-500/30 selection:text-white overflow-x-hidden">
      {/* Dynamic Navigation Bar */}
      <Navbar />

      {/* Hero Welcome Section */}
      <Hero />

      {/* Main Core Content Sections */}
      <main className="relative">
        {/* About Section */}
        <About />

        {/* Dynamic Skills and Capability Indicators */}
        <Skills />

        {/* Education History Vertical Timeline */}
        <Education />

        {/* Projects Showcase & Interactive Map Sandbox */}
        <Projects />

        {/* Work / Volunteer Experiences */}
        <Experience />

        {/* Certificates Accomplishment Board */}
        <Certificates />

        {/* Interests and Personal Hobbies */}
        <Interests />

        {/* Contact Center */}
        <Contact />
      </main>

      {/* Footer Section */}
      <Footer />

      {/* Floating Scroll To Top Anchor Button */}
      <ScrollToTop />
    </div>
  );
}
