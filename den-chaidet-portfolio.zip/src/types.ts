export interface Skill {
  name: string;
  level: number;
  category: 'Tech' | 'Tools';
  color: string;
}

export interface EducationItem {
  institution: string;
  degree: string;
  major: string;
  period: string;
  description?: string;
  highlights?: string[];
}

export interface Project {
  title: string;
  description: string;
  technologies: string[];
  image: string;
  githubUrl: string;
  liveUrl?: string;
}

export interface ExperienceItem {
  role: string;
  organization: string;
  period: string;
  description: string;
  bullets?: string[];
}

export interface Certificate {
  name: string;
  issuer: string;
  year: string;
  iconName: string;
}

export interface Interest {
  name: string;
  iconName: string;
  description: string;
}

export interface ProvinceData {
  id: string;
  name: string;
  khmerName: string;
  capital: string;
  area: string;
  population: string;
  description: string;
  highlights: string[];
  image: string;
  svgPath?: string; // For a simplified SVG map overlay
}
