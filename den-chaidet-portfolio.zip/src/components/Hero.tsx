import { motion } from 'motion/react';
import { ArrowRight, MessageSquare, Download, MapPin, Sparkles, Database, Laptop } from 'lucide-react';

export default function Hero() {
  const handleScrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-28 pb-16 overflow-hidden bg-gradient-to-b from-[#020617] via-[#0b1329] to-[#030712]"
    >
      {/* Decorative dynamic ambient glow points */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-sky-500/10 rounded-full blur-[120px] pointer-events-none animate-pulse-slow"></div>
      <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-indigo-500/10 rounded-full blur-[140px] pointer-events-none animate-float"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Text and Introduction Content */}
          <div className="lg:col-span-7 flex flex-col justify-center text-center lg:text-left order-2 lg:order-1">
            
            {/* Tag/Badge */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-sky-500/10 border border-sky-400/20 text-sky-300 text-xs font-semibold uppercase tracking-widest mx-auto lg:mx-0 w-fit mb-5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Welcome to my Digital Space</span>
            </motion.div>

            {/* Name with elegant display typography */}
            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl sm:text-5xl md:text-6xl font-extrabold font-display tracking-tight text-white mb-2 leading-tight"
            >
              Hi, I'm <span className="text-gradient">Den Chaidet</span>
            </motion.h1>

            {/* Subheading / Role */}
            <motion.h2
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg sm:text-xl font-medium font-display text-sky-200 tracking-wide mb-6 flex items-center justify-center lg:justify-start gap-2 text-sky-300"
            >
              <span>First-Year Digital Economy Student</span>
              <span className="hidden sm:inline-block w-1.5 h-1.5 rounded-full bg-sky-400"></span>
              <span className="text-slate-400 text-sm hidden sm:inline-block">Web Developer & Tech enthusiast</span>
            </motion.h2>

            {/* Precise introductory paragraph */}
            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="text-slate-300 text-sm sm:text-base leading-relaxed mb-8 max-w-2xl font-sans"
            >
              I am a passionate first-year Digital Economy student at the National University of Management with a growing interest in web development, digital technology, and creative problem-solving. I enjoy learning new skills, building practical projects, and continuously improving myself through education, teamwork, and real-world experiences. My goal is to develop innovative digital solutions while expanding my knowledge in technology and business.
            </motion.p>

            {/* Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start"
            >
              <button
                onClick={() => handleScrollTo('projects')}
                className="w-full sm:w-auto bg-gradient-to-r from-sky-400 via-indigo-500 to-purple-600 hover:from-sky-500 hover:via-indigo-600 hover:to-purple-700 text-white font-semibold font-display text-xs px-8 py-4 rounded-xl shadow-xl shadow-indigo-500/20 hover:shadow-indigo-500/30 transition-all duration-200 hover:scale-[1.02] flex items-center justify-center gap-2 group cursor-pointer"
              >
                <span>View Projects</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => handleScrollTo('contact')}
                className="w-full sm:w-auto bg-slate-900/60 hover:bg-slate-800/80 text-white border border-white/10 hover:border-white/20 font-semibold font-display text-xs px-8 py-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 text-sky-400" />
                <span>Contact Me</span>
              </button>
            </motion.div>

            {/* Micro-Details/Labels */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="mt-12 grid grid-cols-3 gap-4 border-t border-white/5 pt-6 max-w-md mx-auto lg:mx-0"
            >
              <div>
                <span className="block text-slate-400 text-[10px] uppercase font-mono tracking-wider">Education</span>
                <span className="block text-white text-xs font-semibold font-display mt-0.5">NUM University</span>
              </div>
              <div>
                <span className="block text-slate-400 text-[10px] uppercase font-mono tracking-wider">Focus</span>
                <span className="block text-white text-xs font-semibold font-display mt-0.5">Digital Economy</span>
              </div>
              <div>
                <span className="block text-slate-400 text-[10px] uppercase font-mono tracking-wider">Location</span>
                <span className="block text-white text-xs font-semibold font-display mt-0.5 flex items-center gap-0.5 justify-center lg:justify-start">
                  <MapPin className="w-3 h-3 text-red-400" /> Phnom Penh
                </span>
              </div>
            </motion.div>

          </div>

          {/* Portrait Placeholder Container / Profile Image */}
          <div className="lg:col-span-5 flex justify-center items-center order-1 lg:order-2">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="relative w-72 h-72 sm:w-80 sm:h-80 md:w-96 md:h-96"
            >
              {/* Spinning / Glowing Outer Rings */}
              <div className="absolute inset-0 bg-gradient-to-tr from-sky-400 to-indigo-600 rounded-full blur-2xl opacity-20 animate-pulse-slow"></div>
              <div className="absolute -inset-2 rounded-[40px] bg-gradient-to-r from-sky-400 via-indigo-500 to-purple-600 opacity-30 blur-lg animate-float"></div>
              
              {/* Outer tech ornaments */}
              <div className="absolute -top-4 -left-4 w-12 h-12 border-t-2 border-l-2 border-sky-400/60 rounded-tl-xl pointer-events-none"></div>
              <div className="absolute -bottom-4 -right-4 w-12 h-12 border-b-2 border-r-2 border-indigo-500/60 rounded-br-xl pointer-events-none"></div>

              {/* Floating Icons of Skill Category */}
              <div className="absolute -top-3 right-6 bg-slate-900/90 border border-white/10 p-2.5 rounded-xl shadow-lg shadow-black/50 animate-float text-sky-400">
                <Database className="w-5 h-5" />
              </div>
              <div className="absolute bottom-10 -left-6 bg-slate-900/90 border border-white/10 p-2.5 rounded-xl shadow-lg shadow-black/50 animate-float text-indigo-400" style={{ animationDelay: '2s' }}>
                <Laptop className="w-5 h-5" />
              </div>

              {/* Image Frame */}
              <div className="relative w-full h-full rounded-[32px] overflow-hidden border-2 border-white/10 glass-card p-3">
                <img
                  src="/src/assets/images/profile_avatar_1784116547850.jpg"
                  alt="Den Chaidet"
                  className="w-full h-full object-cover rounded-[24px] shadow-inner"
                  referrerPolicy="no-referrer"
                />
              </div>

            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
