import { useState, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Phone, MapPin, Send, CheckCircle2, Sparkles } from 'lucide-react';

export default function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) return;

    setIsSubmitting(true);
    
    // Simulate API request
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      setName('');
      setEmail('');
      setMessage('');

      // Reset success notification after 5s
      setTimeout(() => setSubmitSuccess(false), 5000);
    }, 1200);
  };

  return (
    <section id="contact" className="py-24 relative bg-gradient-to-b from-[#020617] via-[#04081c] to-[#01030a] overflow-hidden">
      {/* Decorative ambient lighting */}
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-sky-500/5 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute top-10 left-10 w-96 h-96 bg-indigo-500/5 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center mb-16">
          <span className="text-xs font-semibold text-sky-400 uppercase tracking-widest flex items-center justify-center gap-1.5 mb-1.5">
            <Mail className="w-3.5 h-3.5" /> Connection Hub
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
            Contact <span className="text-gradient">Me</span>
          </h2>
          <div className="w-12 h-1 bg-gradient-to-r from-sky-400 to-indigo-500 mx-auto mt-4 rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 max-w-6xl mx-auto">
          
          {/* Contact Information Cards Column */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div className="space-y-6">
              <h3 className="text-2xl font-bold font-display text-white text-left mb-4">
                Let's Build Something Great
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed text-left mb-8 max-w-md font-sans">
                I am eager to expand my network, collaborate on web projects, and discuss internship or volunteer opportunities. Please feel free to reach out via email, phone, or any social networks!
              </p>

              {/* Individual Contact Detail Items */}
              <div className="space-y-4">
                
                {/* Email Item */}
                <div className="glass-card rounded-xl p-4 border border-white/5 flex items-center gap-4 text-left hover:border-white/10 transition-colors">
                  <div className="p-3 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded-lg flex-shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-400 uppercase tracking-wider font-mono">Email Address</span>
                    <a href="mailto:jjame8497@gmail.com" className="block text-sm font-semibold text-white hover:text-sky-300 transition-colors">
                      jjame8497@gmail.com
                    </a>
                  </div>
                </div>

                {/* Phone Item */}
                <div className="glass-card rounded-xl p-4 border border-white/5 flex items-center gap-4 text-left hover:border-white/10 transition-colors">
                  <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-lg flex-shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-400 uppercase tracking-wider font-mono">Phone Number</span>
                    <a href="tel:0977151966" className="block text-sm font-semibold text-white hover:text-indigo-300 transition-colors">
                      (+855) 097 715 1966
                    </a>
                  </div>
                </div>

                {/* Location Item */}
                <div className="glass-card rounded-xl p-4 border border-white/5 flex items-center gap-4 text-left hover:border-white/10 transition-colors">
                  <div className="p-3 bg-purple-500/10 border border-purple-500/20 text-purple-400 rounded-lg flex-shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-400 uppercase tracking-wider font-mono">Location</span>
                    <span className="block text-sm font-semibold text-white">
                      Phnom Penh, Cambodia
                    </span>
                  </div>
                </div>

              </div>
            </div>

            {/* Social Network Section utilizing Font Awesome icons exactly! */}
            <div className="mt-8 pt-8 border-t border-white/5 text-left">
              <span className="block text-[10px] text-slate-500 uppercase tracking-wider font-mono mb-4">
                Connect on Social Networks
              </span>
              <div className="flex gap-4">
                {/* GitHub link with Font Awesome icon */}
                <a
                  href="https://github.com/jjame8497-oss"
                  target="_blank"
                  rel="noreferrer"
                  className="w-12 h-12 rounded-xl bg-slate-900 border border-white/10 hover:border-sky-400/50 hover:text-sky-300 text-slate-300 flex items-center justify-center transition-all duration-300 hover:scale-105 shadow-md shadow-black/40 group"
                  title="Visit GitHub Profile"
                >
                  <i className="fa-brands fa-github text-xl group-hover:scale-110 transition-transform"></i>
                </a>

                {/* Facebook link with Font Awesome icon */}
                <a
                  href="https://web.facebook.com/profile.php?id=100028330188223"
                  target="_blank"
                  rel="noreferrer"
                  className="w-12 h-12 rounded-xl bg-slate-900 border border-white/10 hover:border-indigo-400/50 hover:text-indigo-300 text-slate-300 flex items-center justify-center transition-all duration-300 hover:scale-105 shadow-md shadow-black/40 group"
                  title="Visit Facebook Profile"
                >
                  <i className="fa-brands fa-facebook text-xl group-hover:scale-110 transition-transform"></i>
                </a>
              </div>
            </div>

          </div>

          {/* Form Column */}
          <div className="lg:col-span-7">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.5 }}
              className="glass-card rounded-2xl p-6 sm:p-8 border border-white/10 relative overflow-hidden text-left"
            >
              <h3 className="text-lg font-bold font-display text-white mb-6">
                Send a Message
              </h3>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label htmlFor="form-name" className="block text-[10px] text-slate-400 uppercase tracking-wider font-mono mb-2">
                    Your Name
                  </label>
                  <input
                    type="text"
                    id="form-name"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-950/60 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400/20 transition-all font-sans"
                    placeholder="Enter your name"
                  />
                </div>

                <div>
                  <label htmlFor="form-email" className="block text-[10px] text-slate-400 uppercase tracking-wider font-mono mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="form-email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-950/60 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400/20 transition-all font-sans"
                    placeholder="name@example.com"
                  />
                </div>

                <div>
                  <label htmlFor="form-message" className="block text-[10px] text-slate-400 uppercase tracking-wider font-mono mb-2">
                    Your Message
                  </label>
                  <textarea
                    id="form-message"
                    required
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full bg-slate-950/60 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400/20 transition-all resize-none font-sans"
                    placeholder="Write your message here..."
                  ></textarea>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-sky-400 to-indigo-500 hover:from-sky-500 hover:to-indigo-600 text-white font-semibold font-display text-xs py-3.5 rounded-xl shadow-lg shadow-sky-500/10 hover:shadow-sky-500/20 transition-all hover:scale-[1.01] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:pointer-events-none"
                >
                  {isSubmitting ? (
                    <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Send Message</span>
                    </>
                  )}
                </button>
              </form>

              {/* Toast/Success modal notifications */}
              <AnimatePresence>
                {submitSuccess && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute inset-x-6 bottom-6 bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 flex items-center gap-3 shadow-lg shadow-emerald-950/20 backdrop-blur-md"
                  >
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-white flex items-center gap-1">
                        Message Sent successfully! <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                      </p>
                      <p className="text-[10px] text-slate-300 mt-0.5">
                        Thank you for reaching out. Den will respond to you soon!
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

            </motion.div>
          </div>

        </div>

      </div>
    </section>
  );
}
