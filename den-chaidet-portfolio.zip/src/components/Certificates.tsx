import { motion } from 'motion/react';
import { Award, BadgeCheck, FileText, CheckCircle, ExternalLink } from 'lucide-react';
import { Certificate } from '../types';

const CERTIFICATES: Certificate[] = [
  {
    name: 'High School Diploma (Bac II)',
    issuer: 'Ministry of Education, Youth and Sport, Cambodia',
    year: 'Graduated in 2025',
    iconName: 'diploma',
  },
  {
    name: 'ACE General English Program Level 12',
    issuer: 'Australian Centre for Education (ACE)',
    year: 'Completed successfully',
    iconName: 'english',
  },
  {
    name: 'IELTS Overall Band Score 6.0',
    issuer: 'IELTS Test Centre (IDP Cambodia)',
    year: 'Certified in 2024',
    iconName: 'ielts',
  },
];

export default function Certificates() {
  const getIconComponent = (type: string) => {
    switch (type) {
      case 'diploma': return Award;
      case 'english': return FileText;
      default: return BadgeCheck;
    }
  };

  return (
    <section id="certificates" className="py-24 relative bg-gradient-to-b from-[#020617] via-[#090e24] to-[#030712] overflow-hidden">
      {/* Decorative ambient background lights */}
      <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-sky-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center mb-16">
          <span className="text-xs font-semibold text-sky-400 uppercase tracking-widest flex items-center justify-center gap-1.5 mb-1.5">
            <Award className="w-3.5 h-3.5" /> Academic Credentials
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
            Certificates & <span className="text-gradient">Achievements</span>
          </h2>
          <div className="w-12 h-1 bg-gradient-to-r from-sky-400 to-indigo-500 mx-auto mt-4 rounded-full"></div>
        </div>

        {/* Certificate Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {CERTIFICATES.map((cert, idx) => {
            const IconComponent = getIconComponent(cert.iconName);
            return (
              <motion.div
                key={cert.name}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-100px' }}
                transition={{ duration: 0.4, delay: idx * 0.1 }}
                className="glass-card rounded-2xl p-6 sm:p-8 border border-white/5 hover:border-white/10 transition-all duration-300 hover:scale-[1.02] flex flex-col justify-between text-left h-full group"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="p-3 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded-xl group-hover:bg-sky-500/20 transition-all">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono font-bold uppercase text-sky-300 bg-sky-500/10 border border-sky-500/20 px-2.5 py-1 rounded-full">
                      Verified
                    </span>
                  </div>

                  <h3 className="text-base font-bold font-display text-white group-hover:text-sky-300 transition-colors leading-snug">
                    {cert.name}
                  </h3>

                  <p className="text-xs text-slate-400 font-sans mt-2">
                    Issued by: {cert.issuer}
                  </p>
                </div>

                <div className="mt-8 pt-4 border-t border-white/5 flex items-center justify-between text-xs text-slate-300">
                  <span className="flex items-center gap-1">
                    <CheckCircle className="w-4 h-4 text-emerald-400" /> {cert.year}
                  </span>
                  <span className="text-[10px] text-indigo-400 font-mono tracking-wider font-semibold uppercase flex items-center gap-1">
                    Academic <ExternalLink className="w-3 h-3" />
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
