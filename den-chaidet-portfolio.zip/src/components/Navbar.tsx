import { useState, useEffect, ComponentType } from 'react';
import { Menu, X, User, Briefcase, GraduationCap, Award, Heart, Phone, FolderCode, Cpu } from 'lucide-react';

interface NavLink {
  id: string;
  label: string;
  icon: ComponentType<any>;
}

const NAV_LINKS: NavLink[] = [
  { id: 'home', label: 'Home', icon: Cpu },
  { id: 'about', label: 'About', icon: User },
  { id: 'skills', label: 'Skills', icon: Cpu },
  { id: 'education', label: 'Education', icon: GraduationCap },
  { id: 'projects', label: 'Projects', icon: FolderCode },
  { id: 'experience', label: 'Experience', icon: Briefcase },
  { id: 'certificates', label: 'Certifications', icon: Award },
  { id: 'contact', label: 'Contact', icon: Phone },
];

export default function Navbar() {
  const [activeSection, setActiveSection] = useState('home');
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Monitor scrolling to change background transparency and track active section
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      // Simple active link detection
      const sections = NAV_LINKS.map(link => document.getElementById(link.id));
      const scrollPosition = window.scrollY + 120; // Offset for navbar

      for (let i = sections.length - 1; i >= 0; i--) {
        const section = sections[i];
        if (section && scrollPosition >= section.offsetTop) {
          setActiveSection(NAV_LINKS[i].id);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80; // height of sticky header
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <header
      id="portfolio-navbar"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled
          ? 'glass-nav py-3.5 shadow-lg shadow-black/30'
          : 'bg-transparent py-5 border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo / Student Brand */}
          <button
            onClick={() => scrollToSection('home')}
            className="flex items-center gap-2 group text-left cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-400 to-indigo-600 flex items-center justify-center text-white font-bold font-display shadow-lg shadow-sky-500/20 group-hover:scale-105 transition-transform duration-200">
              DC
            </div>
            <div>
              <span className="block font-bold text-base font-display text-white tracking-tight leading-none group-hover:text-sky-300 transition-colors">
                Den Chaidet
              </span>
              <span className="block text-[10px] text-slate-400 font-medium tracking-wider mt-0.5 uppercase">
                Digital Economy Student
              </span>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-950/40 p-1.5 rounded-xl border border-white/5">
            {NAV_LINKS.map((link) => {
              const isActive = activeSection === link.id;
              const LinkIcon = link.icon;
              return (
                <button
                  key={link.id}
                  id={`nav-link-${link.id}`}
                  onClick={() => scrollToSection(link.id)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium font-display tracking-wide transition-all duration-200 cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-sky-500/15 to-indigo-500/15 border border-sky-500/30 text-sky-300 shadow-md shadow-sky-500/5'
                      : 'border border-transparent text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <LinkIcon className={`w-3.5 h-3.5 ${isActive ? 'text-sky-400' : 'text-slate-400'}`} />
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Action Button CTA (Connect with me) */}
          <div className="hidden lg:block">
            <button
              onClick={() => scrollToSection('contact')}
              className="bg-gradient-to-r from-sky-400 to-indigo-500 hover:from-sky-500 hover:to-indigo-600 text-white font-medium font-display text-xs px-5 py-2.5 rounded-xl shadow-lg shadow-sky-500/15 hover:shadow-sky-500/25 transition-all duration-200 hover:scale-[1.02] cursor-pointer"
            >
              Get In Touch
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden">
            <button
              id="mobile-menu-btn"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2.5 rounded-xl bg-slate-900/60 border border-white/5 text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      <div
        id="mobile-drawer"
        className={`lg:hidden fixed inset-y-0 right-0 w-72 bg-slate-950/95 backdrop-blur-xl border-l border-white/5 shadow-2xl z-40 transform transition-transform duration-300 ease-out p-6 flex flex-col justify-between ${
          isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="mt-12">
          <div className="border-b border-white/5 pb-4 mb-6">
            <h3 className="font-bold font-display text-white text-lg">Menu</h3>
            <p className="text-xs text-slate-400 mt-0.5">Den Chaidet Portfolio</p>
          </div>
          <nav className="flex flex-col gap-2">
            {NAV_LINKS.map((link) => {
              const isActive = activeSection === link.id;
              const LinkIcon = link.icon;
              return (
                <button
                  key={link.id}
                  id={`mobile-nav-link-${link.id}`}
                  onClick={() => scrollToSection(link.id)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium font-display tracking-wide text-left transition-all duration-200 cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-sky-500/10 to-indigo-500/10 border-l-2 border-sky-400 text-sky-300'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <LinkIcon className={`w-4 h-4 ${isActive ? 'text-sky-400' : 'text-slate-400'}`} />
                  {link.label}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="border-t border-white/5 pt-6 mt-6">
          <button
            onClick={() => scrollToSection('contact')}
            className="w-full text-center bg-gradient-to-r from-sky-400 to-indigo-500 hover:from-sky-500 hover:to-indigo-600 text-white font-medium font-display text-sm py-3 rounded-xl shadow-lg transition-all"
          >
            Contact Me
          </button>
          <div className="text-center mt-4 text-[10px] text-slate-500 font-mono">
            © 2026 Den Chaidet
          </div>
        </div>
      </div>

      {/* Background overlay for mobile drawer */}
      {isMobileMenuOpen && (
        <div
          onClick={() => setIsMobileMenuOpen(false)}
          className="lg:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-30 transition-opacity"
        ></div>
      )}
    </header>
  );
}
