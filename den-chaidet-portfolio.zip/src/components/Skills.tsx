import { motion } from 'motion/react';
import { Cpu, Code, Palette, FileText, Image, Star, Sparkles } from 'lucide-react';
import { Skill } from '../types';

const SKILLS: Skill[] = [
  { name: 'HTML', level: 80, category: 'Tech', color: 'from-orange-500 to-amber-400' },
  { name: 'CSS', level: 70, category: 'Tech', color: 'from-sky-500 to-indigo-400' },
  { name: 'Canva', level: 85, category: 'Tools', color: 'from-purple-500 to-pink-400' },
  { name: 'Microsoft Word', level: 90, category: 'Tools', color: 'from-blue-600 to-sky-400' },
];

export default function Skills() {
  // Split into categories for clean structure
  const techSkills = SKILLS.filter(s => s.category === 'Tech');
  const toolSkills = SKILLS.filter(s => s.category === 'Tools');

  const getSkillIcon = (name: string) => {
    switch (name) {
      case 'HTML': return Code;
      case 'CSS': return Palette;
      case 'Canva': return Image;
      case 'Microsoft Word': return FileText;
      default: return Star;
    }
  };

  return (
    <section id="skills" className="py-24 relative bg-gradient-to-b from-[#020617] via-[#080d22] to-[#030712] overflow-hidden">
      {/* Decorative ambient points */}
      <div className="absolute bottom-1/4 right-0 w-80 h-80 bg-sky-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center mb-16">
          <span className="text-xs font-semibold text-sky-400 uppercase tracking-widest flex items-center justify-center gap-1.5 mb-1.5">
            <Cpu className="w-3.5 h-3.5" /> Capabilities
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
            My <span className="text-gradient">Skills</span>
          </h2>
          <div className="w-12 h-1 bg-gradient-to-r from-sky-400 to-indigo-500 mx-auto mt-4 rounded-full"></div>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          
          {/* Web Development Section */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.5 }}
            className="glass-card rounded-2xl p-6 lg:p-8 border border-white/5 relative"
          >
            <div className="flex items-center gap-3 mb-8 border-b border-white/5 pb-4">
              <div className="p-2.5 bg-sky-500/10 rounded-xl text-sky-400 border border-sky-500/20">
                <Code className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold font-display text-white">Web Development</h3>
                <p className="text-xs text-slate-400 mt-0.5">Core coding and layout layout technologies</p>
              </div>
            </div>

            <div className="space-y-6">
              {techSkills.map((skill) => {
                const Icon = getSkillIcon(skill.name);
                return (
                  <div key={skill.name} className="relative">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4 text-sky-400" />
                        <span className="text-sm font-semibold text-slate-200">{skill.name}</span>
                      </div>
                      <span className="text-xs font-mono font-bold text-sky-400">{skill.level}%</span>
                    </div>
                    {/* Progress Track */}
                    <div className="h-3 bg-slate-900/80 rounded-full overflow-hidden border border-white/5 p-0.5">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, ease: 'easeOut' }}
                        className={`h-full rounded-full bg-gradient-to-r ${skill.color} shadow-lg shadow-sky-500/10`}
                      ></motion.div>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>

          {/* Productivity & Design Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.5 }}
            className="glass-card rounded-2xl p-6 lg:p-8 border border-white/5 relative"
          >
            <div className="flex items-center gap-3 mb-8 border-b border-white/5 pb-4">
              <div className="p-2.5 bg-purple-500/10 rounded-xl text-purple-400 border border-purple-500/20">
                <Palette className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold font-display text-white">Productivity & Design</h3>
                <p className="text-xs text-slate-400 mt-0.5">Creative content and document production tools</p>
              </div>
            </div>

            <div className="space-y-6">
              {toolSkills.map((skill) => {
                const Icon = getSkillIcon(skill.name);
                return (
                  <div key={skill.name} className="relative">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4 text-purple-400" />
                        <span className="text-sm font-semibold text-slate-200">{skill.name}</span>
                      </div>
                      <span className="text-xs font-mono font-bold text-purple-400">{skill.level}%</span>
                    </div>
                    {/* Progress Track */}
                    <div className="h-3 bg-slate-900/80 rounded-full overflow-hidden border border-white/5 p-0.5">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, ease: 'easeOut' }}
                        className={`h-full rounded-full bg-gradient-to-r ${skill.color} shadow-lg shadow-purple-500/10`}
                      ></motion.div>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>

        </div>

        {/* Micro quote below */}
        <div className="mt-12 text-center text-xs text-slate-500 flex items-center justify-center gap-1.5 font-mono">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" /> Self-taught skill growth with weekly learning updates
        </div>

      </div>
    </section>
  );
}
