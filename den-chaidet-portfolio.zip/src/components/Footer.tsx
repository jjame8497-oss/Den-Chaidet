import { Cpu } from 'lucide-react';

export default function Footer() {
  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <footer id="portfolio-footer" className="bg-[#02040a] border-t border-white/5 py-12 relative z-10 text-slate-500 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center gap-6">
        
        {/* Core logo branding */}
        <button
          onClick={handleScrollToTop}
          className="flex items-center gap-2 group text-left cursor-pointer"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-sky-400 to-indigo-600 flex items-center justify-center text-white font-bold text-xs shadow-md">
            DC
          </div>
          <span className="font-bold text-sm font-display text-white tracking-wide group-hover:text-sky-300 transition-colors">
            Den Chaidet
          </span>
        </button>

        <p className="text-xs text-slate-400 leading-relaxed max-w-md">
          First-Year Digital Economy Student passionate about constructing innovative web apps, designing elegant interfaces, and continuous growth.
        </p>

        {/* Legal and design statements */}
        <div className="border-t border-white/5 w-full pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] max-w-4xl">
          <div className="flex items-center gap-1.5 text-slate-400 font-mono">
            <Cpu className="w-3.5 h-3.5 text-sky-400" />
            <span>Digital Economy Portfolio &copy; 2026</span>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-1 sm:gap-4 text-slate-500">
            <span>Designed and Developed by <strong className="text-slate-300">Den Chaidet</strong></span>
            <span className="hidden sm:inline">&middot;</span>
            <span>Built with React &amp; Tailwind</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
