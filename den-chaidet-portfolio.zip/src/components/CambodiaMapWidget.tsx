import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Info, Users, Compass, ChevronRight, Minimize2 } from 'lucide-react';
import { ProvinceData } from '../types';

const PROVINCES: ProvinceData[] = [
  {
    id: 'phnom-penh',
    name: 'Phnom Penh',
    khmerName: 'ភ្នំពេញ',
    capital: 'Phnom Penh',
    area: '679 km²',
    population: '2.2 Million',
    description: 'The vibrant capital and economic hub of Cambodia, situated at the confluence of the Mekong, Tonle Sap, and Bassac rivers. Known for its historical architecture, modern skyscrapers, and rich cultural landmarks.',
    highlights: ['Royal Palace & Silver Pagoda', 'Wat Phnom Historical Site', 'National Museum of Cambodia', 'Sisowath Quay Riverside'],
    image: 'https://images.unsplash.com/photo-1594132332675-52ea7c0f1469?auto=format&fit=crop&w=600&q=80',
    // Position on SVG map
    svgPath: 'M 290 260 L 315 260 L 315 285 L 290 285 Z'
  },
  {
    id: 'siem-reap',
    name: 'Siem Reap',
    khmerName: 'សៀមរាប',
    capital: 'Siem Reap City',
    area: '10,299 km²',
    population: '1.0 Million',
    description: 'The cultural capital of Cambodia and the gateway to the world-famous Angkor Archaeological Park. Siem Reap seamlessly blends ancient wonder with a bustling modern hospitality scene.',
    highlights: ['Angkor Wat Temple complex', 'Bayon & Angkor Thom', 'Pub Street & Night Markets', 'Tonle Sap Floating Villages'],
    image: 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?auto=format&fit=crop&w=600&q=80',
    svgPath: 'M 140 100 L 220 100 L 210 150 L 130 140 Z'
  },
  {
    id: 'preah-sihanouk',
    name: 'Preah Sihanouk',
    khmerName: 'ព្រះសីហនុ',
    capital: 'Sihanoukville',
    area: '2,536 km²',
    population: '310,000',
    description: 'Cambodia\'s premier coastal province, famous for its tropical beaches, beautiful islands, and a rapidly expanding deep-water port. It is the center of maritime commerce and beach tourism.',
    highlights: ['Koh Rong & Koh Rong Sanloem Islands', 'Otres Beach', 'Ream National Park', 'Sihanoukville Port Zone'],
    image: 'https://images.unsplash.com/photo-1540206395-68808572332f?auto=format&fit=crop&w=600&q=80',
    svgPath: 'M 90 290 L 140 290 L 140 330 L 90 330 Z'
  },
  {
    id: 'battambang',
    name: 'Battambang',
    khmerName: 'បាត់ដំបង',
    capital: 'Battambang City',
    area: '11,702 km²',
    population: '1.1 Million',
    description: 'The agricultural powerhouse and "rice bowl" of Cambodia. Celebrated for its preserved French colonial architecture, fertile fields, traditional bamboo trains, and vibrant artistic community.',
    highlights: ['Phnom Banan & Phnom Sampeau', 'Traditional Bamboo Train', 'French Colonial Heritage Center', 'Phare Ponleu Selpak Circus'],
    image: 'https://images.unsplash.com/photo-1614741118887-7a4ee193a5fa?auto=format&fit=crop&w=600&q=80',
    svgPath: 'M 50 110 L 120 120 L 110 170 L 40 150 Z'
  },
  {
    id: 'kampot',
    name: 'Kampot',
    khmerName: 'កំពត',
    capital: 'Kampot City',
    area: '4,873 km²',
    population: '650,000',
    description: 'A charming southern province flanked by rivers and mountains, internationally renowned for producing Kampot Pepper, widely recognized as some of the finest pepper in the world.',
    highlights: ['Bokor National Park & Hill Station', 'Kampot Pepper Plantations', 'Prek Tuek Chhou River Cruises', 'Colonial Riverside Streets'],
    image: 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=600&q=80',
    svgPath: 'M 150 290 L 210 290 L 210 330 L 150 330 Z'
  },
  {
    id: 'mondulkiri',
    name: 'Mondulkiri',
    khmerName: 'មណ្ឌលគិរី',
    capital: 'Senmonorom',
    area: '14,288 km²',
    population: '90,000',
    description: 'The largest and most sparsely populated province, located in the eastern highlands. Characterized by rolling hills, lush pine forests, dramatic waterfalls, and indigenous Bunong cultures.',
    highlights: ['Bousra Waterfall', 'Elephant Valley Sanctuary', 'Coffee Plantations', 'Sea Forest Viewpoint'],
    image: 'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=600&q=80',
    svgPath: 'M 360 170 L 450 170 L 450 240 L 350 230 Z'
  },
  {
    id: 'ratanakiri',
    name: 'Ratanakiri',
    khmerName: 'រតនគិរី',
    capital: 'Banlung',
    area: '10,782 km²',
    population: '220,000',
    description: 'An eastern mountainous wilderness bordering Vietnam and Laos, famous for its unique volcanic crater lakes, gemstone mines, national parks, and diverse ethnic minority villages.',
    highlights: ['Yeak Laom Volcanic Lake', 'Kachang & Katieng Waterfalls', 'Virachey National Park Trekking', 'Indigenous Village Tours'],
    image: 'https://images.unsplash.com/photo-1542224566-6e85f2e6772f?auto=format&fit=crop&w=600&q=80',
    svgPath: 'M 360 80 L 450 80 L 450 160 L 350 160 Z'
  },
  {
    id: 'kep',
    name: 'Kep',
    khmerName: 'កែប',
    capital: 'Kep City',
    area: '336 km²',
    population: '45,000',
    description: 'Cambodia\'s smallest province, renowned as a tranquil seaside resort town. Celebrated for its fresh crab markets, beautiful national park trails, and French colonial-era villas.',
    highlights: ['Kep Crab Market', 'Kep National Park Trails', 'Rabbit Island (Koh Tonsay)', 'White Horse Statue'],
    image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=600&q=80',
    svgPath: 'M 175 340 L 195 340 L 195 355 L 175 355 Z'
  }
];

// Stylized extra regions to fill the map background & make it look like a fully fledged interactive map!
const DECORATIVE_REGIONS = [
  { id: 'oddar-meanchey', name: 'Oddar Meanchey', svgPath: 'M 110 50 L 180 50 L 170 90 L 100 90 Z' },
  { id: 'banteay-meanchey', name: 'Banteay Meanchey', svgPath: 'M 30 70 L 100 80 L 90 120 L 30 110 Z' },
  { id: 'preah-vihear', name: 'Preah Vihear', svgPath: 'M 190 50 L 270 50 L 260 110 L 180 100 Z' },
  { id: 'stung-treng', name: 'Stung Treng', svgPath: 'M 280 50 L 350 50 L 350 120 L 270 120 Z' },
  { id: 'kompong-thom', name: 'Kompong Thom', svgPath: 'M 220 110 L 270 120 L 260 180 L 210 160 Z' },
  { id: 'pursat', name: 'Pursat', svgPath: 'M 120 150 L 160 160 L 140 220 L 80 200 Z' },
  { id: 'kratie', name: 'Kratie', svgPath: 'M 280 130 L 340 130 L 340 190 L 270 190 Z' },
  { id: 'kompong-chnang', name: 'Kompong Chhnang', svgPath: 'M 170 170 L 210 180 L 200 220 L 150 210 Z' },
  { id: 'kompong-speu', name: 'Kompong Speu', svgPath: 'M 150 220 L 210 230 L 200 280 L 140 270 Z' },
  { id: 'takeo', name: 'Takeo', svgPath: 'M 220 290 L 280 290 L 270 340 L 210 330 Z' },
  { id: 'kandal', name: 'Kandal', svgPath: 'M 230 260 L 285 260 L 285 300 L 220 300 Z' },
  { id: 'prey-veng', name: 'Prey Veng', svgPath: 'M 295 220 L 345 220 L 345 270 L 295 270 Z' },
  { id: 'svay-rieng', name: 'Svay Rieng', svgPath: 'M 350 250 L 395 250 L 395 300 L 350 290 Z' },
  { id: 'koh-kong', name: 'Koh Kong', svgPath: 'M 50 200 L 130 210 L 120 280 L 50 270 Z' },
  { id: 'tboung-khmum', name: 'Tboung Khmum', svgPath: 'M 310 195 L 355 195 L 355 240 L 310 240 Z' }
];

export default function CambodiaMapWidget() {
  const [selectedId, setSelectedId] = useState<string>('phnom-penh');
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const selectedProvince = PROVINCES.find((p) => p.id === selectedId) || PROVINCES[0];

  return (
    <div id="cambodia-map-playground" className="glass-card rounded-2xl p-6 lg:p-8 relative overflow-hidden">
      {/* Visual background lights */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="flex items-center justify-between mb-6 pb-4 border-b border-white/5 relative z-10">
        <div>
          <span className="text-xs font-semibold text-sky-400 uppercase tracking-widest flex items-center gap-1.5 mb-1">
            <Compass className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '8s' }} /> Interactive Showcase
          </span>
          <h4 className="text-2xl font-bold font-display text-white">Cambodia Map Playground</h4>
        </div>
        <div className="text-xs font-mono bg-white/5 text-white/60 px-2.5 py-1 rounded-full border border-white/10 hidden sm:block">
          Click on regions or sidebar list
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 relative z-10">
        
        {/* SVG Interactive Map Column */}
        <div className="lg:col-span-7 flex flex-col items-center justify-center bg-slate-950/40 rounded-xl p-4 border border-white/5 relative">
          <div className="absolute top-3 left-3 text-[10px] font-mono text-slate-500 uppercase tracking-wider">
            Vector Projection v1.2
          </div>
          
          <div className="w-full max-w-md aspect-[5/4] relative">
            <svg
              viewBox="0 0 500 380"
              className="w-full h-full drop-shadow-[0_12px_24px_rgba(0,0,0,0.6)]"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Central Water Body - Tonle Sap Lake */}
              <motion.ellipse
                cx="165"
                cy="175"
                rx="35"
                ry="15"
                transform="rotate(-25 165 175)"
                fill="#0284c7"
                fillOpacity="0.45"
                stroke="#38bdf8"
                strokeWidth="1.5"
                className="animate-pulse-slow pointer-events-none"
              />
              <text x="140" y="180" fill="#38bdf8" fontSize="8" fontFamily="sans-serif" fontWeight="bold" opacity="0.7" className="pointer-events-none select-none">
                Tonle Sap
              </text>

              {/* Draw Decorative/Background Provinces */}
              {DECORATIVE_REGIONS.map((region) => (
                <path
                  key={region.id}
                  d={region.svgPath}
                  fill="#1e293b"
                  fillOpacity="0.15"
                  stroke="rgba(255, 255, 255, 0.05)"
                  strokeWidth="1"
                  className="transition-all duration-300 pointer-events-none"
                />
              ))}

              {/* Draw Main Clickable Focus Provinces */}
              {PROVINCES.map((province) => {
                const isSelected = province.id === selectedId;
                const isHovered = province.id === hoveredId;

                return (
                  <path
                    key={province.id}
                    d={province.svgPath}
                    id={`map-province-${province.id}`}
                    className="cursor-pointer transition-all duration-300"
                    fill={isSelected ? '#312e81' : isHovered ? '#1e1b4b' : '#0f172a'}
                    fillOpacity={isSelected ? 0.7 : isHovered ? 0.5 : 0.3}
                    stroke={isSelected ? '#38bdf8' : isHovered ? '#818cf8' : 'rgba(255, 255, 255, 0.15)'}
                    strokeWidth={isSelected ? 2 : isHovered ? 1.5 : 1}
                    onMouseEnter={() => setHoveredId(province.id)}
                    onMouseLeave={() => setHoveredId(null)}
                    onClick={() => setSelectedId(province.id)}
                  />
                );
              })}

              {/* Name Labels over selected / hovered provinces */}
              {PROVINCES.map((province) => {
                const isSelected = province.id === selectedId;
                if (!isSelected) return null;

                // Simple coordinate calculation based on paths to center text labels roughly
                let labelX = 250;
                let labelY = 200;
                if (province.id === 'phnom-penh') { labelX = 300; labelY = 255; }
                if (province.id === 'siem-reap') { labelX = 175; labelY = 125; }
                if (province.id === 'preah-sihanouk') { labelX = 115; labelY = 320; }
                if (province.id === 'battambang') { labelX = 80; labelY = 135; }
                if (province.id === 'kampot') { labelX = 180; labelY = 310; }
                if (province.id === 'mondulkiri') { labelX = 400; labelY = 205; }
                if (province.id === 'ratanakiri') { labelX = 405; labelY = 120; }
                if (province.id === 'kep') { labelX = 210; labelY = 355; }

                return (
                  <g key={`label-${province.id}`} className="pointer-events-none select-none">
                    <circle cx={labelX} cy={labelY} r="3.5" fill="#38bdf8" className="animate-ping" />
                    <circle cx={labelX} cy={labelY} r="2.5" fill="#38bdf8" />
                    <rect
                      x={labelX - 45}
                      y={labelY - 26}
                      width="90"
                      height="18"
                      rx="3"
                      fill="#030712"
                      fillOpacity="0.85"
                      stroke="#38bdf8"
                      strokeWidth="0.5"
                    />
                    <text
                      x={labelX}
                      y={labelY - 14}
                      textAnchor="middle"
                      fill="#ffffff"
                      fontSize="8"
                      fontFamily="sans-serif"
                      fontWeight="bold"
                    >
                      {province.name}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Quick list selectors for mobile and tablet sizing */}
          <div className="w-full grid grid-cols-4 sm:grid-cols-4 gap-2 mt-4">
            {PROVINCES.map((p) => {
              const isSelected = p.id === selectedId;
              return (
                <button
                  key={`btn-${p.id}`}
                  id={`btn-select-${p.id}`}
                  onClick={() => setSelectedId(p.id)}
                  className={`text-[10px] py-1.5 px-1 rounded font-display transition-all duration-200 border text-center truncate ${
                    isSelected
                      ? 'bg-gradient-to-r from-sky-500/20 to-indigo-500/20 border-sky-400 text-sky-300 font-semibold shadow-md shadow-sky-900/10'
                      : 'bg-slate-900/40 border-white/5 text-slate-400 hover:border-white/10 hover:text-white'
                  }`}
                >
                  {p.name}
                </button>
              );
            })}
          </div>
        </div>

        {/* Dynamic Card Column */}
        <div className="lg:col-span-5 flex flex-col justify-between">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedProvince.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="flex flex-col h-full justify-between"
            >
              <div>
                <div className="relative rounded-xl overflow-hidden aspect-[16/9] mb-4 border border-white/10 group">
                  <img
                    src={selectedProvince.image}
                    alt={selectedProvince.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>
                  <div className="absolute bottom-3 left-3 flex items-end justify-between right-3">
                    <div>
                      <h5 className="text-xl font-bold font-display text-white flex items-center gap-1.5">
                        {selectedProvince.name}
                      </h5>
                      <p className="text-xs text-sky-300 font-medium tracking-wide">
                        {selectedProvince.khmerName}
                      </p>
                    </div>
                    <div className="text-[10px] uppercase tracking-widest font-mono bg-sky-500/20 text-sky-300 border border-sky-500/30 px-2 py-0.5 rounded">
                      Featured
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-white/5 border border-white/5 rounded-lg p-2.5 flex items-center gap-2">
                    <div className="p-1.5 bg-indigo-500/10 rounded-md text-indigo-400">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider font-mono">Capital</div>
                      <div className="text-xs font-semibold text-white truncate">{selectedProvince.capital}</div>
                    </div>
                  </div>

                  <div className="bg-white/5 border border-white/5 rounded-lg p-2.5 flex items-center gap-2">
                    <div className="p-1.5 bg-sky-500/10 rounded-md text-sky-400">
                      <Users className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider font-mono">Pop.</div>
                      <div className="text-xs font-semibold text-white truncate">{selectedProvince.population}</div>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  {selectedProvince.description}
                </p>

                <div className="mb-4">
                  <div className="text-[10px] text-slate-400 uppercase tracking-wider font-mono mb-2 flex items-center gap-1">
                    <Info className="w-3.5 h-3.5 text-sky-400" /> Key Attractions & Highlights
                  </div>
                  <ul className="space-y-1.5">
                    {selectedProvince.highlights.map((highlight, index) => (
                      <li key={index} className="text-xs text-slate-200 flex items-center gap-1.5">
                        <ChevronRight className="w-3.5 h-3.5 text-sky-400 flex-shrink-0" />
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-4 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-400">
                <span className="flex items-center gap-1">
                  <Compass className="w-3.5 h-3.5 text-indigo-400" /> Area: {selectedProvince.area}
                </span>
                <span className="text-sky-300 font-mono">Click live demo to open full app</span>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

      </div>
    </div>
  );
}
