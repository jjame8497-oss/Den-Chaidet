import { motion } from 'motion/react';
import { Heart, Headphones, Film, Compass, Book, Sparkles } from 'lucide-react';
import { Interest } from '../types';

const INTERESTS: Interest[] = [
  {
    name: 'Listening to Music',
    iconName: 'music',
    description: 'Enjoys exploring a wide array of musical genres to focus, spark design inspiration, and unwind during study breaks.',
  },
  {
    name: 'Watching Movies',
    iconName: 'movies',
    description: 'Fascinated by cinematic storytelling, cinematography techniques, and futuristic tech-fiction narratives.',
  },
  {
    name: 'Traveling',
    iconName: 'travel',
    description: 'Eager to discover historical landscapes, experience regional cultures, and explore nature across Cambodia.',
  },
  {
    name: 'Reading Books',
    iconName: 'reading',
    description: 'Loves reading self-improvement, technology blogs, history, and digital business journals to broaden horizons.',
  },
];

export default function Interests() {
  const getIcon = (name: string) => {
    switch (name) {
      case 'music': return Headphones;
      case 'movies': return Film;
      case 'travel': return Compass;
      default: return Book;
    }
  };

  return (
    <section id="interests" className="py-24 relative bg-gradient-to-b from-[#030712] via-[#050b1d] to-[#020617] overflow-hidden">
      {/* Visual background lights */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center mb-16">
          <span className="text-xs font-semibold text-sky-400 uppercase tracking-widest flex items-center justify-center gap-1.5 mb-1.5">
            <Heart className="w-3.5 h-3.5" /> Personal Side
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
            Interests & <span className="text-gradient">Hobbies</span>
          </h2>
          <div className="w-12 h-1 bg-gradient-to-r from-sky-400 to-indigo-500 mx-auto mt-4 rounded-full"></div>
        </div>

        {/* Interests Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {INTERESTS.map((item, idx) => {
            const Icon = getIcon(item.iconName);
            return (
              <motion.div
                key={item.name}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-100px' }}
                transition={{ duration: 0.4, delay: idx * 0.1 }}
                className="glass-card rounded-2xl p-6 border border-white/5 hover:border-white/10 transition-all duration-300 hover:scale-[1.02] flex flex-col items-start text-left h-full group"
              >
                <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl mb-5 group-hover:bg-indigo-500/20 transition-all">
                  <Icon className="w-5 h-5" />
                </div>

                <h3 className="text-base font-bold font-display text-white mb-2 group-hover:text-sky-300 transition-colors">
                  {item.name}
                </h3>

                <p className="text-xs text-slate-400 leading-relaxed font-sans">
                  {item.description}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Dynamic subquote */}
        <div className="mt-12 text-center text-xs text-slate-500 flex items-center justify-center gap-1.5 font-mono">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" style={{ animationDuration: '6s' }} /> Curating experiences to fuel creative problem solving
        </div>

      </div>
    </section>
  );
}
