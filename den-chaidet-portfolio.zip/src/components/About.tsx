import { motion } from 'motion/react';
import { User, BookOpen, Rocket, Award, GraduationCap, Briefcase, Heart, CheckCircle2 } from 'lucide-react';

export default function About() {
  const points = [
    {
      icon: GraduationCap,
      title: 'Digital Economy Student',
      description: 'First-year student at the National University of Management, exploring the fusion of modern economics and emerging technology.',
      color: 'text-sky-400 bg-sky-500/10 border-sky-500/20',
    },
    {
      icon: BookOpen,
      title: 'Continuous Learning',
      description: 'Genuinely eager to learn new technologies and frameworks. Committing daily effort to self-improvement and technical skill development.',
      color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20',
    },
    {
      icon: Rocket,
      title: 'Web Development Passion',
      description: 'Deeply fascinated by front-end design, interactive user interfaces, and structuring clean, accessible code.',
      color: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
    },
    {
      icon: Briefcase,
      title: 'Internship Ready',
      description: 'Actively seeking internship and entry-level professional opportunities to acquire hands-on experience and contribute value to real-world projects.',
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
    },
  ];

  return (
    <section id="about" className="py-24 relative bg-gradient-to-b from-[#030712] via-[#050a1e] to-[#020617] overflow-hidden">
      {/* Visual backdrops */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center mb-16">
          <span className="text-xs font-semibold text-sky-400 uppercase tracking-widest flex items-center justify-center gap-1.5 mb-1.5">
            <User className="w-3.5 h-3.5" /> Professional Profile
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
            About <span className="text-gradient">Me</span>
          </h2>
          <div className="w-12 h-1 bg-gradient-to-r from-sky-400 to-indigo-500 mx-auto mt-4 rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Large Card Details Panel */}
          <div className="lg:col-span-5">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.5 }}
              className="glass-card rounded-2xl p-8 border border-white/10 relative overflow-hidden h-full flex flex-col justify-between"
            >
              {/* Overlay elements */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/5 rounded-full blur-2xl pointer-events-none"></div>
              
              <div>
                <h3 className="text-xl font-bold font-display text-white mb-4">
                  My Path & Vision
                </h3>
                <p className="text-slate-300 text-sm leading-relaxed mb-6">
                  Entering the field of <span className="text-sky-300 font-semibold">Digital Economy</span> has given me a unique perspective that joins technical tools with business strategy. I don't just write code; I strive to understand how applications and digital systems solve real human needs, drive efficiency, and create commercial value.
                </p>
                <p className="text-slate-300 text-sm leading-relaxed mb-6">
                  As a first-year student, I treat every day as a clean slate to acquire new skills. I am dedicated, highly disciplined, and thrive inside collaborative environments where ideas flow freely and team-members challenge each other.
                </p>
              </div>

              {/* Bullet Quick Check List */}
              <div className="space-y-3.5 border-t border-white/5 pt-6 mt-2">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-sky-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="block text-xs font-semibold text-white">Full Commitment to Growth</span>
                    <span className="block text-[11px] text-slate-400">Regular self-study, research, and project-building</span>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-indigo-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="block text-xs font-semibold text-white">Pragmatic Mindset</span>
                    <span className="block text-[11px] text-slate-400">Balancing business principles and front-end tools</span>
                  </div>
                </div>
              </div>

            </motion.div>
          </div>

          {/* Grid Layout of Pillars */}
          <div className="lg:col-span-7">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {points.map((p, idx) => {
                const Icon = p.icon;
                return (
                  <motion.div
                    key={p.title}
                    initial={{ opacity: 0, y: 15 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: '-100px' }}
                    transition={{ duration: 0.4, delay: idx * 0.1 }}
                    className="glass-card rounded-2xl p-6 border border-white/5 hover:border-white/10 transition-all duration-300 hover:scale-[1.02] flex flex-col items-start text-left"
                  >
                    <div className={`p-3 rounded-xl border mb-4 ${p.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <h4 className="text-base font-bold font-display text-white mb-2">
                      {p.title}
                    </h4>
                    <p className="text-slate-400 text-xs leading-relaxed">
                      {p.description}
                    </p>
                  </motion.div>
                );
              })}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
