import { motion } from 'motion/react';
import { GraduationCap, School, Languages, Calendar, Award, CheckCircle } from 'lucide-react';
import { EducationItem } from '../types';

const EDUCATION: EducationItem[] = [
  {
    institution: 'National University of Management',
    degree: 'Bachelor of Science',
    major: 'Digital Economy',
    period: '2025 – Present',
    description: 'Focusing on the intersections of digital technology, commerce, global economics, and software tools. Building foundational concepts in tech-business integration and modern digital platforms.',
    highlights: ['First-Year Student status', 'Expanding skills in web development', 'Participating in digital commerce case reviews'],
  },
  {
    institution: 'Preah Yukunthor High School',
    degree: 'High School Diploma (Bac II)',
    major: 'General Studies',
    period: 'Graduated in 2025',
    description: 'Completed secondary education with solid academic foundations in Phnom Penh, Cambodia.',
    highlights: ['Graduated successfully in 2025', 'Active in peer study circles', 'Focused on sciences and social studies'],
  },
  {
    institution: 'ACE (Australian Centre for Education)',
    degree: 'General English Program',
    major: 'Level: GEP 12',
    period: 'IELTS 6.0 (2024)',
    description: 'Enrolled in high-tier academic English training, culminating in GEP 12 graduation and language certifications.',
    highlights: ['IELTS Overall Band Score 6.0 (2024)', 'Advanced written and verbal communications', 'Intercultural collaboration projects'],
  },
];

export default function Education() {
  const getIcon = (inst: string) => {
    if (inst.toLowerCase().includes('management')) return School;
    if (inst.toLowerCase().includes('high school')) return GraduationCap;
    return Languages;
  };

  return (
    <section id="education" className="py-24 relative bg-gradient-to-b from-[#030712] via-[#050b1d] to-[#020617] overflow-hidden">
      {/* Background visual light */}
      <div className="absolute top-1/3 left-10 w-96 h-96 bg-indigo-500/5 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center mb-16">
          <span className="text-xs font-semibold text-sky-400 uppercase tracking-widest flex items-center justify-center gap-1.5 mb-1.5">
            <GraduationCap className="w-3.5 h-3.5" /> Academic Background
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
            Education <span className="text-gradient">Timeline</span>
          </h2>
          <div className="w-12 h-1 bg-gradient-to-r from-sky-400 to-indigo-500 mx-auto mt-4 rounded-full"></div>
        </div>

        {/* Timeline Path */}
        <div className="relative max-w-4xl mx-auto">
          
          {/* Vertical Center Line (Desktop) */}
          <div className="absolute left-8 md:left-1/2 top-2 bottom-2 w-0.5 bg-gradient-to-b from-sky-500 via-indigo-500 to-purple-600 opacity-20"></div>

          <div className="space-y-12">
            {EDUCATION.map((item, idx) => {
              const Icon = getIcon(item.institution);
              const isEven = idx % 2 === 0;

              return (
                <div key={item.institution} className="relative flex flex-col md:flex-row items-start md:items-center">
                  
                  {/* Timeline Node Point */}
                  <div className="absolute left-8 md:left-1/2 transform -translate-x-1/2 z-20">
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      className="w-12 h-12 rounded-full bg-slate-900 border-2 border-sky-400/80 flex items-center justify-center text-sky-400 shadow-lg shadow-sky-500/25 cursor-pointer"
                    >
                      <Icon className="w-5 h-5" />
                    </motion.div>
                  </div>

                  {/* Left / Right Card Layout */}
                  <div className={`w-full md:w-1/2 pl-16 md:pl-0 ${isEven ? 'md:pr-16 md:text-right' : 'md:pl-16 md:order-2'}`}>
                    <motion.div
                      initial={{ opacity: 0, y: 15 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: '-100px' }}
                      transition={{ duration: 0.5, delay: idx * 0.1 }}
                      className="glass-card rounded-2xl p-6 md:p-8 border border-white/5 hover:border-white/10 transition-all duration-300 relative group"
                    >
                      {/* Timeline Year Badge */}
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-[10px] font-mono font-bold text-indigo-300 mb-4 ${
                        isEven ? 'md:flex-row-reverse' : ''
                      }`}>
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{item.period}</span>
                      </span>

                      <h3 className="text-xl font-bold font-display text-white group-hover:text-sky-300 transition-colors">
                        {item.institution}
                      </h3>
                      
                      <p className="text-xs font-semibold text-sky-300 mt-1 uppercase tracking-wider font-mono">
                        {item.degree} — <span className="text-slate-300 font-sans normal-case font-medium">{item.major}</span>
                      </p>

                      <p className="text-xs text-slate-400 mt-4 leading-relaxed">
                        {item.description}
                      </p>

                      {/* Timeline highlights bullet lists */}
                      {item.highlights && item.highlights.length > 0 && (
                        <div className={`mt-4 pt-4 border-t border-white/5 flex flex-col gap-1.5 ${
                          isEven ? 'md:items-end' : 'md:items-start'
                        }`}>
                          {item.highlights.map((h, hIdx) => (
                            <div key={hIdx} className={`flex items-center gap-2 text-xs text-slate-200 ${
                              isEven ? 'md:flex-row-reverse' : ''
                            }`}>
                              <CheckCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                              <span>{h}</span>
                            </div>
                          ))}
                        </div>
                      )}

                    </motion.div>
                  </div>

                  {/* Empty Spacer Column for Desktop */}
                  <div className="hidden md:block w-1/2"></div>

                </div>
              );
            })}
          </div>

        </div>

      </div>
    </section>
  );
}
