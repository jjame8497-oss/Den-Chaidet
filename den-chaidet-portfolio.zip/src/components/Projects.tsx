import { motion } from 'motion/react';
import { FolderCode, Github, ExternalLink, Sparkles, Terminal, MapPin } from 'lucide-react';
import CambodiaMapWidget from './CambodiaMapWidget';
import { Project } from '../types';

const PROJECTS: Project[] = [
  {
    title: 'Interactive Map of Cambodia',
    description: 'Developed a responsive web application displaying an interactive map of Cambodia. Users can select or hover over individual provinces to view cultural data, administrative capitals, population statistics, and key tourist attractions in real time. Designed to optimize geographical data presentation and enhance user involvement.',
    technologies: ['HTML5', 'CSS3', 'JavaScript (ES6)', 'SVG Vectors', 'Responsive UI'],
    image: '/src/assets/images/cambodia_map_project_1784116563201.jpg',
    githubUrl: 'https://github.com/jjame8497-oss',
  }
];

export default function Projects() {
  const handleScrollToPlayground = () => {
    const element = document.getElementById('cambodia-map-playground');
    if (element) {
      const offset = 100;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section id="projects" className="py-24 relative bg-gradient-to-b from-[#020617] via-[#091128] to-[#030712] overflow-hidden">
      {/* Decorative ambient gradients */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-indigo-500/5 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-sky-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center mb-16">
          <span className="text-xs font-semibold text-sky-400 uppercase tracking-widest flex items-center justify-center gap-1.5 mb-1.5">
            <FolderCode className="w-3.5 h-3.5" /> Featured Works
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
            My <span className="text-gradient">Projects</span>
          </h2>
          <div className="w-12 h-1 bg-gradient-to-r from-sky-400 to-indigo-500 mx-auto mt-4 rounded-full"></div>
        </div>

        {/* Project Card Showcase */}
        <div className="max-w-4xl mx-auto mb-16">
          {PROJECTS.map((project) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.5 }}
              className="glass-card rounded-2xl overflow-hidden border border-white/10 shadow-2xl shadow-black/60 grid grid-cols-1 md:grid-cols-12 gap-0 relative group"
            >
              {/* Image Column */}
              <div className="md:col-span-5 relative aspect-[4/3] md:aspect-auto overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-slate-950 via-slate-950/20 to-transparent"></div>
                
                {/* Tech Badge indicator */}
                <div className="absolute top-4 left-4 flex items-center gap-1 bg-slate-950/80 backdrop-blur-md border border-white/10 px-3 py-1.5 rounded-lg text-[10px] text-sky-400 font-mono font-bold uppercase tracking-wider">
                  <Terminal className="w-3.5 h-3.5" /> Live Sandbox Included
                </div>
              </div>

              {/* Information Details Column */}
              <div className="md:col-span-7 p-6 sm:p-8 flex flex-col justify-between text-left">
                <div>
                  <div className="flex items-center gap-1.5 text-[10px] text-sky-400 uppercase tracking-widest font-mono font-bold mb-2">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Academic Project
                  </div>
                  
                  <h3 className="text-2xl font-bold font-display text-white mb-4 group-hover:text-sky-300 transition-colors">
                    {project.title}
                  </h3>

                  <p className="text-xs text-slate-300 leading-relaxed mb-6 font-sans">
                    {project.description}
                  </p>

                  {/* Technology Tags */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="text-[10px] font-mono font-semibold px-2.5 py-1 rounded-md bg-white/5 border border-white/5 text-slate-300"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Card CTA Actions */}
                <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-white/5">
                  <button
                    onClick={handleScrollToPlayground}
                    className="flex items-center gap-1.5 bg-gradient-to-r from-sky-400 to-indigo-500 hover:from-sky-500 hover:to-indigo-600 text-white font-semibold font-display text-xs px-5 py-3 rounded-xl shadow-lg transition-all hover:scale-[1.02] cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Launch Live Demo</span>
                  </button>

                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 bg-slate-900/60 hover:bg-slate-800/80 text-white border border-white/10 hover:border-white/20 font-semibold font-display text-xs px-5 py-3 rounded-xl shadow-md transition-all"
                  >
                    <Github className="w-4 h-4 text-slate-400" />
                    <span>View GitHub</span>
                  </a>
                </div>

              </div>
            </motion.div>
          ))}
        </div>

        {/* Embedded Live Map Sandbox Module */}
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h4 className="text-lg font-bold font-display text-white/90 mb-1 flex items-center justify-center gap-2">
              <MapPin className="w-4 h-4 text-sky-400" /> Live Interactive Map Showcase
            </h4>
            <p className="text-xs text-slate-400">
              Test out the exact functionality of Den's project live right here:
            </p>
          </div>
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.5 }}
          >
            <CambodiaMapWidget />
          </motion.div>
        </div>

      </div>
    </section>
  );
}
