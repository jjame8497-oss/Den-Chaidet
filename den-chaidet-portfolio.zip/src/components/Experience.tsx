import { motion } from 'motion/react';
import { Briefcase, Heart, Calendar, Target, CheckCircle2 } from 'lucide-react';
import { ExperienceItem } from '../types';

const EXPERIENCES: ExperienceItem[] = [
  {
    role: 'Volunteer',
    organization: 'One Health Student Club',
    period: '2025 – Present',
    description: 'Contributing active support, organization skills, and student teamwork to promote public and community health awareness.',
    bullets: [
      'Helped organize club activities and health-awareness outreach campaigns.',
      'Collaborated closely with cross-functional student teams on volunteer events.',
      'Facilitated student engagement workshops, improving communication and logistics coordination skills.',
    ],
  },
];

export default function Experience() {
  return (
    <section id="experience" className="py-24 relative bg-gradient-to-b from-[#030712] via-[#060a20] to-[#020617] overflow-hidden">
      {/* Decorative background light */}
      <div className="absolute bottom-1/3 left-1/4 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none animate-float"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center mb-16">
          <span className="text-xs font-semibold text-sky-400 uppercase tracking-widest flex items-center justify-center gap-1.5 mb-1.5">
            <Briefcase className="w-3.5 h-3.5" /> Practical Experience
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
            Work & <span className="text-gradient">Volunteer History</span>
          </h2>
          <div className="w-12 h-1 bg-gradient-to-r from-sky-400 to-indigo-500 mx-auto mt-4 rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch max-w-5xl mx-auto">
          
          {/* Volunteer Experience Column */}
          <div className="lg:col-span-7 flex">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.5 }}
              className="glass-card rounded-2xl p-6 sm:p-8 border border-white/5 hover:border-white/10 transition-all duration-300 flex flex-col justify-between w-full text-left"
            >
              <div>
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/5 pb-4 mb-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-sky-500/10 border border-sky-500/20 rounded-xl text-sky-400">
                      <Heart className="w-5 h-5 animate-pulse" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold font-display text-white">Volunteer</h3>
                      <p className="text-xs text-slate-300 font-semibold">{EXPERIENCES[0].organization}</p>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-white/5 text-[10px] font-mono text-slate-400">
                    <Calendar className="w-3 h-3" /> 2025 – Present
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed mb-6">
                  {EXPERIENCES[0].description}
                </p>

                <ul className="space-y-3.5">
                  {EXPERIENCES[0].bullets?.map((bullet, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-200">
                      <CheckCircle2 className="w-4 h-4 text-sky-400 flex-shrink-0 mt-0.5" />
                      <span>{bullet}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-8 pt-4 border-t border-white/5 text-[10px] text-slate-400 font-mono">
                Location: Phnom Penh, Cambodia (On-Site Activities)
              </div>
            </motion.div>
          </div>

          {/* Career Goal / Target Column */}
          <div className="lg:col-span-5 flex">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.5 }}
              className="bg-gradient-to-br from-indigo-950/40 to-slate-950/80 border border-indigo-500/20 rounded-2xl p-6 sm:p-8 flex flex-col justify-between w-full relative overflow-hidden text-left"
            >
              {/* Top ambient highlight glow */}
              <div className="absolute top-0 right-0 w-40 h-40 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>

              <div>
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2.5 bg-indigo-500/15 border border-indigo-500/30 rounded-xl text-indigo-400">
                    <Target className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold font-display text-white">Career Goal</h3>
                </div>

                <h4 className="text-base font-bold font-display text-sky-300 mb-3">
                  Seeking Internships & Professional Growth
                </h4>

                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  Currently seeking internship, junior, and professional opportunities in digital business, web development, or creative design.
                </p>

                <p className="text-xs text-slate-300 leading-relaxed mb-6">
                  My aim is to apply academic concepts from my Digital Economy studies, collaborate with skilled professionals, and actively build high-quality technical skills in real-world team environments.
                </p>
              </div>

              <div className="border-t border-white/5 pt-4 flex flex-col gap-2">
                <span className="text-[10px] font-mono text-slate-400">Current Availability:</span>
                <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/25 px-3 py-1.5 rounded-lg w-fit">
                  Open for Opportunities (Part-Time / Full-Time Intern)
                </span>
              </div>
            </motion.div>
          </div>

        </div>

      </div>
    </section>
  );
}
